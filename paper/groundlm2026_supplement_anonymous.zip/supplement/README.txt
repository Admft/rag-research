Anonymous supplementary material for GroundLM 2026 submission.
Contents: eval questions, grid config, scoring.py (judge cap),
summary.csv (82 runs), ablation summary.json files, pre-fix A8/A9 archives.
No author names or machine paths included.
